from abc import ABC, abstractmethod

class PriceRepository(ABC):

    @abstractmethod
    def get_prices(self, ticker, start, end):
        pass